"use client";

import * as React from "react";
import { cn } from "./utils";
import { X, CheckCircle, AlertCircle, Info } from "lucide-react";

interface Toast {
  id: string;
  message: string;
  type: 'success' | 'error' | 'info' | 'default';
  duration?: number;
}

interface ToasterProps {
  position?: 'top-right' | 'top-left' | 'bottom-right' | 'bottom-left' | 'top-center' | 'bottom-center';
  className?: string;
}

const ToastContext = React.createContext<{
  toasts: Toast[];
  addToast: (toast: Omit<Toast, 'id'>) => void;
  removeToast: (id: string) => void;
}>({
  toasts: [],
  addToast: () => {},
  removeToast: () => {},
});

export const useToast = () => React.useContext(ToastContext);

// Simple toast implementation
export const toast = {
  success: (message: string) => {
    // This will work when the ToastProvider is present
    const event = new CustomEvent('toast', { 
      detail: { message, type: 'success' } 
    });
    window.dispatchEvent(event);
  },
  error: (message: string) => {
    const event = new CustomEvent('toast', { 
      detail: { message, type: 'error' } 
    });
    window.dispatchEvent(event);
  },
  info: (message: string) => {
    const event = new CustomEvent('toast', { 
      detail: { message, type: 'info' } 
    });
    window.dispatchEvent(event);
  },
};

function ToastProvider({ children }: { children: React.ReactNode }) {
  const [toasts, setToasts] = React.useState<Toast[]>([]);

  const addToast = React.useCallback((toast: Omit<Toast, 'id'>) => {
    const id = Math.random().toString(36).substring(2, 9);
    const newToast = { ...toast, id };
    
    setToasts((prev) => [...prev, newToast]);

    // Auto remove after duration
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, toast.duration || 4000);
  }, []);

  const removeToast = React.useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  // Listen for custom toast events
  React.useEffect(() => {
    const handleToast = (event: CustomEvent) => {
      addToast(event.detail);
    };

    window.addEventListener('toast', handleToast as EventListener);
    return () => window.removeEventListener('toast', handleToast as EventListener);
  }, [addToast]);

  return (
    <ToastContext.Provider value={{ toasts, addToast, removeToast }}>
      {children}
    </ToastContext.Provider>
  );
}

const Toaster = ({ position = "bottom-right", className }: ToasterProps) => {
  const { toasts, removeToast } = useToast();

  const positionClasses = {
    'top-right': 'top-4 right-4',
    'top-left': 'top-4 left-4',
    'bottom-right': 'bottom-4 right-4',
    'bottom-left': 'bottom-4 left-4',
    'top-center': 'top-4 left-1/2 -translate-x-1/2',
    'bottom-center': 'bottom-4 left-1/2 -translate-x-1/2',
  };

  const getIcon = (type: Toast['type']) => {
    switch (type) {
      case 'success':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'error':
        return <AlertCircle className="h-4 w-4 text-red-500" />;
      case 'info':
        return <Info className="h-4 w-4 text-blue-500" />;
      default:
        return null;
    }
  };

  if (toasts.length === 0) return null;

  return (
    <div className={cn("fixed z-50 space-y-2", positionClasses[position], className)}>
      {toasts.map((toast) => (
        <div
          key={toast.id}
          className={cn(
            "flex items-center gap-3 rounded-lg border bg-background p-4 shadow-lg transition-all duration-300 ease-in-out",
            "min-w-[300px] max-w-[450px]",
            toast.type === 'success' && "border-green-200 bg-green-50 dark:border-green-800 dark:bg-green-950",
            toast.type === 'error' && "border-red-200 bg-red-50 dark:border-red-800 dark:bg-red-950",
            toast.type === 'info' && "border-blue-200 bg-blue-50 dark:border-blue-800 dark:bg-blue-950"
          )}
        >
          {getIcon(toast.type)}
          <p className="flex-1 text-sm">{toast.message}</p>
          <button
            onClick={() => removeToast(toast.id)}
            className="opacity-70 hover:opacity-100 transition-opacity"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      ))}
    </div>
  );
};

// Wrap the app with ToastProvider
const ToasterWithProvider = (props: ToasterProps) => (
  <ToastProvider>
    <Toaster {...props} />
  </ToastProvider>
);

export { ToasterWithProvider as Toaster, ToastProvider };