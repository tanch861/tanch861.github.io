
  # Там, где уют 2026

  This is a code bundle for Там, где уют 2026. The original project is available at https://www.figma.com/design/JmX5GywGUx2OlQxuZOXRIN/%D0%A2%D0%B0%D0%BC--%D0%B3%D0%B4%D0%B5-%D1%83%D1%8E%D1%82-2026.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  